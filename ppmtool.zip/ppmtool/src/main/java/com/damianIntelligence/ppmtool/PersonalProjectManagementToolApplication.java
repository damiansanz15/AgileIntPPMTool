package com.damianIntelligence.ppmtool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonalProjectManagementToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonalProjectManagementToolApplication.class, args);
	}

}
